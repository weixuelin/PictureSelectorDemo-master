# PictureSelectorDemo

<br>

CSDN：[https://blog.csdn.net/yechaoa/article/details/79291552](https://blog.csdn.net/yechaoa/article/details/79291552) 

> demo更新到最新版本，并稍微调整。

<br>

![](https://github.com/yechaoa/PictureSelectorDemo/raw/master/pic/Screenshot_20180208-151435.png)
![](https://github.com/yechaoa/PictureSelectorDemo/raw/master/pic/Screenshot_20180208-151515.png)
![](https://github.com/yechaoa/PictureSelectorDemo/raw/master/pic/Screenshot_20180208-151505.png)
![](https://github.com/yechaoa/PictureSelectorDemo/raw/master/pic/Screenshot_20180208-151909.png)
